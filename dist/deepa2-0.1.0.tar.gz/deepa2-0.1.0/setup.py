# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['deepa2', 'deepa2.scripts']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=3.0.3,<4.0.0',
 'datasets>=1.18.0,<2.0.0',
 'ipykernel>=6.7.0,<7.0.0',
 'networkx>=2.6.3,<3.0.0',
 'numpy>=1.22.1,<2.0.0',
 'pandas>=1.4.0,<2.0.0',
 'pyarrow>=6.0.1,<7.0.0',
 'requests>=2.27.1,<3.0.0',
 'typer[all]>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['build-aifdb = deepa2.scripts.build_aifdb:app',
                     'build-nli = deepa2.scripts.build_nli:app',
                     'deepa2 = deepa2.main:app']}

setup_kwargs = {
    'name': 'deepa2',
    'version': '0.1.0',
    'description': 'Apps for casting NLP data as multiangular datasets compatible with the DeepA2 framework',
    'long_description': "![unit tests](https://github.com/debatelab/deepa2-datasets/actions/workflows/run_pytest.yml/badge.svg) ![code quality](https://github.com/debatelab/deepa2-datasets/actions/workflows/code_quality_checks.yml/badge.svg)\n\n# deepa2-datasets\n\nResources for Creating, Importing and Managing DeepA2 Argument Analysis Framework Datasets.\n\n* [Documentation](docs/)\n* DeepA2 Datasets\n\n## Getting Started\n\nInstall [poetry](https://python-poetry.org/docs/#installation). \n\nClone the repository:\n```bash\ngit clone https://github.com/debatelab/deepa2-datasets.git\n```\n\nInstall this package from within the repo's root folder:\n```bash\npoetry install\n```\n\nRun a script, e.g.:\n```bash\npoetry run build-nli esnli --debug-size 300 --export-path ./data/processed\n```\n\n## Contribute a DeepA2Builder for another Dataset\n\nWe welcome contributions to this repository, especially scripts that port existing datasets to the DeepA2 Framework. Within this repo, a code module that transforms data into the DeepA2 format contains\n\n1. a Builder class that describes how DeepA2 examples will be constructed and that implements the abstract `core.Builder` interface (such as, e.g., `nli_builder.ESNLIBuilder`);\n2. a DataLoader which provides a method for loading the raw data as a HF Dataset object (such as, for example, `aifdb_builder.AIFDBLoader`) -- you may use `core.DataLoader` as is in case the data is available in a way compatible with HF Dataset;\n3. dataclasses which describe the features of the raw data and the preprocessed data, and which extend the dummy classes `core.RawExample` and `core.PreprocessedExample`;\n4. a script that defines a typer app / command for transforming the original data, using the concrete builder (such as, e.g., `scripts/build_nli.py`);\n5. a collection of unit tests that check the concrete Builder's methods (such as, e.g., `tests/test_esnli.py`);\n6. a documentation of the pipeline (as for example in `docs/esnli.md`).\n\nConsider **suggesting** to collaboratively construct such a pipeline by opening a [new issue](https://github.com/debatelab/deepa2-datasets/issues).\n\n## Citation\n\nThis repository builds on and extends the DeepA2 Framework originally presented in:\n\n```bibtex\n@misc{betz2021deepa2,\n      title={DeepA2: A Modular Framework for Deep Argument Analysis with Pretrained Neural Text2Text Language Models}, \n      author={Gregor Betz and Kyle Richardson},\n      year={2021},\n      eprint={2110.01509},\n      archivePrefix={arXiv},\n      primaryClass={cs.CL}\n}\n```",
    'author': 'Gregor Betz',
    'author_email': 'gregor.betz@kit.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
