"""Preprocessing DeepA2 datasets for LM training"""
# flake8: noqa

from deepa2.preptrain.t2tpreprocessor import T2TPreprocessor
