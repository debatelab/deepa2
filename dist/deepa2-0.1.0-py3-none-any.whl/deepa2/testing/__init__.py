"""BaseTestClasses for pytest"""
# flake8: noqa

from deepa2.testing.buildertester import BaseBuilderTest
